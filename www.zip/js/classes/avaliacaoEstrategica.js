function AvaliacaoEstrategica(){
    this.forca;
    this.fraquesa;
    this.oprotunidade;
    this.ameaca;
}
