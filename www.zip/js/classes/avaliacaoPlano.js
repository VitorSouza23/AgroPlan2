function AvaliacaoDoPlano(){
  this.avalicao;
}
