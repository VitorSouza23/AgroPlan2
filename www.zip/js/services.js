angular.module('starter.services', ['starter.services.utilitarios',
'starter.services.geradorPDF'])
