function Usuario(){
  this.cpf;
  this.nome;
  this.senha;
}
