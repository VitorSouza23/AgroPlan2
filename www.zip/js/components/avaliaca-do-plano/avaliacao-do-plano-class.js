function AvaliacaoDoPlano(){
  this._id;
  this.avalicao;
  this.desativado = false;
}
