function PlanoDeNegocio(){
  this._id;
  this.nome;
  this.analiseDeMercadoID = {};
  this.avaliacaoDoPlanoID = {};
  this.avaliacaoEstrategicaID = {};
  this.construcaoDeCenariosID = {};
  this.planoDeMarketingID = {};
  this.planoOperacionalID = {};
  this.planoFinanceiroID = {};
  this.roteiroDeInformacaoID = {};
  this.sumarioExecutivoID = {};
  this.idUsuario;
  this.desativado = false;
}
