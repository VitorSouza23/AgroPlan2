function AvaliacaoEstrategica(){
  this._id;
    this.forca;
    this.fraquesa;
    this.oprotunidade;
    this.ameaca;
    this.desativado = false;
}
